@extends('master.master')
@section('title') PRIKAZ SVIH @endsection



@section('content')


@if($kljuc)
@foreach($kljuc as $auto)
<br> Ime - {{$auto->model}} //
 Jacina automobila - {{$auto->jacina_automobila}} //
 Opis autmobila - {{$auto->opis}} 







<a href="{{route('izbrisi', ['id' => $auto->id]) }}"><button type="button" class="btn btn-sm btn-danger">Izbrisi me</button></a>

<a href="{{route('update.forma', ['id' => $auto->id]) }}"><button type="button" class="btn btn-sm btn-primary">Izmijeni me</button></a>

@endforeach
@endif


<br>
<br>
<a href="/unos">Unesi novi auto</a>


















@endsection
