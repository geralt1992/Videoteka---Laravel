@extends('master.master')
@section('title') UNOS NOVOG AUTOMOBILA @endsection



@section('content')



IZMIJENI SVOJE PODATKE




<form method="POST" action="{{route('izmijena.podataka' , ['id' => $id]) }}">
    {{csrf_field()}}
    <div class="form-group">
        <label for="title">Model automobila</label>
        <input type="text" class="form-control" id="model" name="model"
        aria-describedby="title" placeholder="Unesi model automobila">
    </div>

    <div class="form-group">
        <label for="title">Unesi jačinu automobila</label>
        <input type="number" class="form-control" id="jacina" name="jacina"
        aria-describedby="title" placeholder="Unesi jačinu automobila">
    </div>


    <div class="form-group">
        <label for="description">Opis</label>
        <textarea class="form-control" id="id_description" rows="3" name="opis" 
        placeholder="Opis"></textarea>
    </div>

    <button type="submit" class="btn btn-primary">Create post</button>
    </form>



@endsection
