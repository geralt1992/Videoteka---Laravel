<?php $__env->startSection('title'); ?> UNOS NOVOG AUTOMOBILA <?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>





<form method="POST" action="#">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="title">Model automobila</label>
        <input type="text" class="form-control" id="model" name="model"
        aria-describedby="title" placeholder="Unesi model automobila">
    </div>

    <div class="form-group">
        <label for="title">Unesi jačinu automobila</label>
        <input type="number" class="form-control" id="jacina" name="jacina"
        aria-describedby="title" placeholder="Unesi jačinu automobila">
    </div>


    <div class="form-group">
        <label for="description">Opis</label>
        <textarea class="form-control" id="id_description" rows="3" name="opis" 
        placeholder="Opis"></textarea>
    </div>

    <button type="submit" class="btn btn-primary">Create post</button>
    </form>

<br>
<br>
<a href="/prikaz_svih">Prikaži sve aute</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\moj_projekt\resources\views/unos_auto.blade.php ENDPATH**/ ?>