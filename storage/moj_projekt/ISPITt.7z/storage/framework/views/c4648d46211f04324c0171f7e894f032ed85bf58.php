<?php $__env->startSection('title'); ?> PRIKAZ SVIH <?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>


<?php if($kljuc): ?>
<?php $__currentLoopData = $kljuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<br> Ime - <?php echo e($auto->model); ?> //
 Jacina automobila - <?php echo e($auto->jacina_automobila); ?> //
 Opis autmobila - <?php echo e($auto->opis); ?> 







<a href="<?php echo e(route('izbrisi', ['id' => $auto->id])); ?>"><button type="button" class="btn btn-sm btn-danger">Izbrisi me</button></a>

<a href="<?php echo e(route('update.forma', ['id' => $auto->id])); ?>"><button type="button" class="btn btn-sm btn-primary">Izmijeni me</button></a>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<br>
<br>
<a href="/unos">Unesi novi auto</a>


















<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\moj_projekt\resources\views/prikaz_svih.blade.php ENDPATH**/ ?>