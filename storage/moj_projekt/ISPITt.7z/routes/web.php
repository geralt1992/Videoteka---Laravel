<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//1. crud (create)
Route::get('/unos', 'autoController@prikaz')->name("forma"); 
Route::post('/unos', 'autoController@unos')->name("unos");

//2. crud (read)
Route::get('/prikaz_svih', 'autoController@prikaz_svih')->name("svi"); 

//3. crud (delete)
Route::get('/prikaz_svih//delete/{id}', 'autoController@delete')->name("izbrisi");

//4. crud (read)
Route::get('/prikaz_update_forme/{id}' , 'autoController@update_forma')->name("update.forma");
Route::post('/prikaz_update_formee/{id}' , 'autoController@izmijena')->name("izmijena.podataka");

