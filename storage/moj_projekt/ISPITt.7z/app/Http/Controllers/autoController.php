<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;



use App\auto;

class autoController extends Controller
{
    public function prikaz(){
        return view('unos_auto');
       }
    

       public function unos(Request $request){
          $auto = new auto;
          $auto->model = $request->model;
          $auto->jacina_automobila = $request->jacina;
          $auto->opis = $request->opis;
          $auto->save();

          return redirect()->route('forma');
       }







       public function prikaz_svih(){
        $autos = auto::get();
        return view('prikaz_svih' , ['kljuc' => $autos]);
       }








       public function delete($id){
        $auto = auto::find($id);
        $auto->delete();
        return redirect()->route('svi');
       }

       













     //  return view('post.index', ['posts' => $posts, 'archives' => $archives]);



    public function update_forma($id){
        $auto = auto::find($id);
        return view('update_forma' , ['id' => $id] );
    }

    public function izmijena(Request $request, $id){
        $auto = auto::find($id);
        $auto->model = $request->model;
        $auto->jacina_automobila = $request->jacina;
        $auto->opis = $request->opis;
        $auto->save();

        return redirect()->route('svi');
    }



}//kraj klase 
